IDE Used: CodeLite
Compiler Used: GCC
